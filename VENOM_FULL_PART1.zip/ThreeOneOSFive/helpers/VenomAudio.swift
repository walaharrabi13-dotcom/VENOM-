import Foundation
import AVFoundation

/// Small UI sounds extracted from the supplied VENOM video. Background playback stays muted.
enum VenomAudio {
    private static var players: [AVAudioPlayer] = []
    private static let lock = NSLock()

    private static var enabled: Bool {
        UserDefaults.standard.object(forKey: "venom.soundsEnabled") as? Bool ?? true
    }

    static func click() { play("venom_click") }
    static func activated() { play("venom_on") }
    static func deactivated() { play("venom_off") }
    static func welcomeOnce() { }

    private static func play(_ resource: String) {
        guard enabled, let url = Bundle.main.url(forResource: resource, withExtension: "wav") else { return }
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.ambient, mode: .default, options: [.mixWithOthers])
            try session.setActive(true, options: .notifyOthersOnDeactivation)
            let player = try AVAudioPlayer(contentsOf: url)
            player.volume = 1.0
            player.prepareToPlay()
            lock.lock()
            players.removeAll { !$0.isPlaying }
            players.append(player)
            lock.unlock()
            player.play()
        } catch {
            // Sound playback is optional and must not interrupt the UI.
        }
    }
}
