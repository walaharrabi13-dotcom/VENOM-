import Combine
import Foundation
import Security

@MainActor
final class LicenseManager: ObservableObject {
    @Published private(set) var expirationDate: Date?
    @Published private(set) var isActive = false
    @Published private(set) var isBusy = false
    @Published private(set) var message: String?

    /// Global maintenance state from VENOM API V2 (`/api/client/status`).
    @Published private(set) var isMaintenance = false
    @Published private(set) var maintenanceMessage = "System under maintenance"
    @Published private(set) var maintenanceChecked = false

    /// Device quota returned by the license / client endpoints.
    @Published private(set) var deviceCount: Int?
    @Published private(set) var deviceLimit: Int?

    /// True when this device fingerprint is banned server-side.
    @Published private(set) var isDeviceBanned = false
    @Published private(set) var banMessage: String?

    /// Client-facing notifications fetched from the API.
    @Published private(set) var notifications: [VenomNotification] = []

    private let service = "com.VENOM.external-ios.activation"
    private let keyAccount = "license-key"
    private let tokenAccount = "activation-token"
    private let deviceAccount = "device-uuid"
    private let baseURL = URL(string: "https://venom-api-v-2--i76241724.replit.app")!

    init() {
        expirationDate = string(for: "license-expiry").flatMap(Self.parseDate)
        isActive = false
    }

    struct VenomNotification: Identifiable, Equatable {
        let id: String
        let title: String
        let body: String
        let createdAt: String?
    }

    var hasRememberedKey: Bool {
        let key = string(for: keyAccount) ?? ""
        let validTime = expirationDate.map { $0 > Date() } ?? true
        return !key.isEmpty && validTime
    }

    var activationToken: String? { string(for: tokenAccount) }

    func beginLaunchSession() {
        // Always show the activation screen on a fresh app launch.
        // A previously activated key is prefilled from Keychain and can be verified with one tap.
        isActive = false
        message = hasRememberedKey ? "Saved license found — tap VERIFY KEY." : "Enter your VENOM license key"
        Task { await refreshMaintenanceStatus() }
    }

    /// Re-check the saved key / token with the server every time the app becomes active.
    func verifyRememberedKey() {
        guard !isBusy else { return }
        guard expirationDate.map({ $0 > Date() }) ?? true else {
            deactivate(message: "License expired. Please activate again.")
            return
        }

        isBusy = true
        Task {
            defer { isBusy = false }
            await refreshMaintenanceStatus()

            // Prefer token-based verification via /api/client/me
            if let token = activationToken, !token.isEmpty {
                do {
                    let me = try await fetchClientMe(token: token)
                    applyDeviceQuota(count: me.deviceCount, limit: me.deviceLimit)
                    if me.banned {
                        markBanned(message: me.message)
                        return
                    }
                    if me.valid {
                        clearBan()
                        expirationDate = me.expiresAt ?? expirationDate
                        if let expiry = expirationDate {
                            save(ISO8601DateFormatter().string(from: expiry), for: "license-expiry")
                        }
                        isActive = true
                        message = "License verified successfully."
                        await refreshNotifications()
                        return
                    } else {
                        deactivate(message: me.message ?? "This license is no longer valid.")
                        return
                    }
                } catch {
                    // Fall through to key re-activation if token path fails
                }
            }

            guard let savedKey = rememberedKey(), !savedKey.isEmpty else {
                if hasRememberedKey {
                    isActive = true
                    message = "Server verification unavailable — cached license still valid."
                }
                return
            }

            do {
                let deviceID = getOrCreateDeviceID()
                let result = try await sendActivation(key: savedKey, deviceID: deviceID)
                applyDeviceQuota(count: result.deviceCount, limit: result.deviceLimit)
                if result.banned {
                    markBanned(message: result.message)
                    return
                }
                guard result.valid else {
                    deactivate(message: result.message ?? "This license is no longer valid.")
                    return
                }
                clearBan()
                if let token = result.token {
                    save(token, for: tokenAccount)
                }
                expirationDate = result.expiresAt ?? expirationDate
                if let expiry = expirationDate {
                    save(ISO8601DateFormatter().string(from: expiry), for: "license-expiry")
                }
                isActive = true
                message = "License verified successfully."
                await refreshNotifications()
            } catch {
                if hasRememberedKey {
                    isActive = true
                    message = "Server verification unavailable — cached license still valid."
                } else {
                    isActive = false
                    message = error.localizedDescription
                }
            }
        }
    }

    func activate(key: String) {
        let normalized = key.uppercased().filter { $0.isLetter || $0.isNumber }
        // Accept 18-char license keys and shorter free codes
        guard !normalized.isEmpty, normalized.count <= 32, !isBusy else {
            message = "Enter a valid license key or free code"
            return
        }

        isBusy = true
        message = "Connecting to VENOM License Server…"

        Task {
            defer { isBusy = false }
            do {
                let deviceID = getOrCreateDeviceID()
                let result = try await sendActivation(key: normalized, deviceID: deviceID)
                applyDeviceQuota(count: result.deviceCount, limit: result.deviceLimit)
                if result.banned {
                    markBanned(message: result.message)
                    return
                }
                guard result.valid else {
                    message = result.message ?? "This license key is invalid or unavailable"
                    isActive = false
                    return
                }

                clearBan()
                expirationDate = result.expiresAt
                save(normalized, for: keyAccount)
                if let token = result.token {
                    save(token, for: tokenAccount)
                } else {
                    delete(tokenAccount)
                }
                if let expiry = result.expiresAt {
                    save(ISO8601DateFormatter().string(from: expiry), for: "license-expiry")
                } else {
                    delete("license-expiry")
                }
                isActive = true
                message = "Activated successfully. License saved on this device."
                await refreshNotifications()
            } catch {
                isActive = false
                message = error.localizedDescription
            }
        }
    }

    private func applyDeviceQuota(count: Int?, limit: Int?) {
        if let count { deviceCount = count }
        if let limit { deviceLimit = limit }
    }

    private func markBanned(message: String?) {
        isDeviceBanned = true
        banMessage = message ?? "This device is banned."
        isActive = false
        self.message = banMessage
        delete(tokenAccount)
    }

    private func clearBan() {
        isDeviceBanned = false
        banMessage = nil
    }

    func refreshNotifications() async {
        var request = URLRequest(url: baseURL.appendingPathComponent("api/notifications"))
        request.httpMethod = "GET"
        request.timeoutInterval = 12
        if let token = activationToken, !token.isEmpty {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        // Also try a client-facing path if the admin path is protected.
        let urls = [
            baseURL.appendingPathComponent("api/client/notifications"),
            baseURL.appendingPathComponent("api/notifications")
        ]
        for url in urls {
            var req = request
            req.url = url
            do {
                let (data, response) = try await URLSession.shared.data(for: req)
                guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
                    continue
                }
                let parsed = Self.parseNotifications(data)
                if !parsed.isEmpty || http.statusCode == 200 {
                    notifications = parsed
                    return
                }
            } catch {
                continue
            }
        }
    }

    private static func parseNotifications(_ data: Data) -> [VenomNotification] {
        let json = (try? JSONSerialization.jsonObject(with: data))
        let raw: [[String: Any]]
        if let arr = json as? [[String: Any]] {
            raw = arr
        } else if let obj = json as? [String: Any] {
            raw = (obj["items"] as? [[String: Any]])
                ?? (obj["notifications"] as? [[String: Any]])
                ?? (obj["data"] as? [[String: Any]])
                ?? []
        } else {
            return []
        }
        return raw.compactMap { dict in
            let title = (dict["title"] as? String) ?? (dict["headline"] as? String) ?? "Notification"
            let body = (dict["body"] as? String)
                ?? (dict["message"] as? String)
                ?? (dict["content"] as? String)
                ?? ""
            let id = (dict["id"] as? String) ?? UUID().uuidString
            let created = (dict["createdAt"] as? String) ?? (dict["created_at"] as? String)
            return VenomNotification(id: id, title: title, body: body, createdAt: created)
        }
    }

    func rememberedKey() -> String? { string(for: keyAccount) }

    func refresh() {
        beginLaunchSession()
        verifyRememberedKey()
    }

    func deactivate(message: String = "Activation removed from this device") {
        delete(keyAccount)
        delete(tokenAccount)
        delete("license-expiry")
        expirationDate = nil
        isActive = false
        deviceCount = nil
        deviceLimit = nil
        if !isDeviceBanned {
            self.message = message
        }
    }

    func enforceExpiration() {
        guard isActive, let expirationDate, expirationDate <= Date() else { return }
        deactivate(message: "License expired. Please activate again.")
    }

    // MARK: - Maintenance

    func refreshMaintenanceStatus() async {
        do {
            let status = try await fetchMaintenanceStatus()
            isMaintenance = status.maintenance
            if let msg = status.message, !msg.isEmpty {
                maintenanceMessage = msg
            } else {
                maintenanceMessage = status.maintenance ? "System under maintenance" : "System online"
            }
        } catch {
            // On network failure keep previous value; default to not blocking the user.
        }
        maintenanceChecked = true
    }

    // MARK: - Networking

    private struct ActivationResult {
        let valid: Bool
        let expiresAt: Date?
        let token: String?
        let message: String?
        let deviceCount: Int?
        let deviceLimit: Int?
        let banned: Bool
    }

    private struct ClientMeResult {
        let valid: Bool
        let expiresAt: Date?
        let message: String?
        let deviceCount: Int?
        let deviceLimit: Int?
        let banned: Bool
    }

    private struct MaintenanceStatus: Decodable {
        let maintenance: Bool
        let message: String?
        let updatedAt: String?
        let serviceName: String?
    }

    private func sendActivation(key: String, deviceID: String) async throws -> ActivationResult {
        let url = baseURL.appendingPathComponent("api/licenses/activate")
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = 20
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "key": key,
            "deviceId": deviceID,
            "externalUserId": deviceID
        ])

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw NSError(domain: "VENOMLicense", code: -1, userInfo: [NSLocalizedDescriptionKey: "Invalid server response"])
        }

        let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]

        if http.statusCode == 200 {
            let message = (json["message"] as? String) ?? (json["error"] as? String)
            let banned = Self.isBannedPayload(json, message: message)
            let valid = ((json["valid"] as? Bool) ?? true) && !banned
            if !valid {
                return ActivationResult(
                    valid: false,
                    expiresAt: nil,
                    token: nil,
                    message: message ?? (banned ? "This device is banned." : "This license key is invalid or unavailable"),
                    deviceCount: Self.intValue(json, keys: ["deviceCount", "device_count", "usedDevices"]),
                    deviceLimit: Self.intValue(json, keys: ["deviceLimit", "device_limit", "maxDevices"]),
                    banned: banned
                )
            }
            let token = (json["activationToken"] as? String)
                ?? (json["token"] as? String)
                ?? (json["accessToken"] as? String)
            let expiresRaw = (json["expiresAt"] as? String) ?? (json["expires_at"] as? String)
            return ActivationResult(
                valid: true,
                expiresAt: expiresRaw.flatMap(Self.parseDate),
                token: token,
                message: message,
                deviceCount: Self.intValue(json, keys: ["deviceCount", "device_count", "usedDevices"]),
                deviceLimit: Self.intValue(json, keys: ["deviceLimit", "device_limit", "maxDevices"]),
                banned: false
            )
        }

        let serverMessage = (json["message"] as? String)
            ?? (json["error"] as? String)
            ?? "License server error (HTTP \(http.statusCode))."
        if Self.isBannedPayload(json, message: serverMessage) {
            return ActivationResult(
                valid: false,
                expiresAt: nil,
                token: nil,
                message: serverMessage,
                deviceCount: nil,
                deviceLimit: nil,
                banned: true
            )
        }
        throw NSError(domain: "VENOMLicense", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: serverMessage])
    }

    private func fetchClientMe(token: String) async throws -> ClientMeResult {
        let url = baseURL.appendingPathComponent("api/client/me")
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.timeoutInterval = 15

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw NSError(domain: "VENOMLicense", code: -1, userInfo: [NSLocalizedDescriptionKey: "Invalid server response"])
        }

        let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]

        if http.statusCode == 200 {
            if let error = json["error"] as? String {
                let banned = Self.isBannedPayload(json, message: error)
                return ClientMeResult(
                    valid: false,
                    expiresAt: nil,
                    message: error,
                    deviceCount: Self.intValue(json, keys: ["deviceCount", "device_count", "usedDevices"]),
                    deviceLimit: Self.intValue(json, keys: ["deviceLimit", "device_limit", "maxDevices"]),
                    banned: banned
                )
            }
            let licenseObj = json["license"] as? [String: Any]
            let expiresRaw = (json["expiresAt"] as? String)
                ?? (json["expires_at"] as? String)
                ?? (licenseObj?["expiresAt"] as? String)
            let message = json["message"] as? String
            let banned = Self.isBannedPayload(json, message: message)
            let valid = ((json["valid"] as? Bool) ?? (json["active"] as? Bool) ?? true) && !banned
            return ClientMeResult(
                valid: valid,
                expiresAt: expiresRaw.flatMap(Self.parseDate),
                message: message,
                deviceCount: Self.intValue(json, keys: ["deviceCount", "device_count", "usedDevices"])
                    ?? Self.intValue(licenseObj ?? [:], keys: ["deviceCount", "device_count", "usedDevices"]),
                deviceLimit: Self.intValue(json, keys: ["deviceLimit", "device_limit", "maxDevices"])
                    ?? Self.intValue(licenseObj ?? [:], keys: ["deviceLimit", "device_limit", "maxDevices"]),
                banned: banned
            )
        }

        let msg = (json["error"] as? String) ?? (json["message"] as? String) ?? "Session invalid"
        return ClientMeResult(
            valid: false,
            expiresAt: nil,
            message: msg,
            deviceCount: nil,
            deviceLimit: nil,
            banned: Self.isBannedPayload(json, message: msg)
        )
    }

    private static func isBannedPayload(_ json: [String: Any], message: String?) -> Bool {
        if (json["banned"] as? Bool) == true { return true }
        if (json["isBanned"] as? Bool) == true { return true }
        if let status = (json["status"] as? String)?.lowercased(),
           status.contains("ban") || status == "blocked" {
            return true
        }
        let haystack = (message ?? "").lowercased()
        return haystack.contains("ban") || haystack.contains("blocked") || haystack.contains("device banned")
    }

    private static func intValue(_ json: [String: Any], keys: [String]) -> Int? {
        for key in keys {
            if let value = json[key] as? Int { return value }
            if let value = json[key] as? NSNumber { return value.intValue }
            if let value = json[key] as? String, let parsed = Int(value) { return parsed }
        }
        return nil
    }

    private func fetchMaintenanceStatus() async throws -> MaintenanceStatus {
        let url = baseURL.appendingPathComponent("api/client/status")
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 10
        let (data, _) = try await URLSession.shared.data(for: request)
        return try JSONDecoder().decode(MaintenanceStatus.self, from: data)
    }

    private func getOrCreateDeviceID() -> String {
        if let existing = string(for: deviceAccount), !existing.isEmpty { return existing }
        let newID = UUID().uuidString
        save(newID, for: deviceAccount)
        return newID
    }

    nonisolated private static func parseDate(_ value: String) -> Date? {
        let fractional = ISO8601DateFormatter()
        fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = fractional.date(from: value) { return date }
        let standard = ISO8601DateFormatter()
        return standard.date(from: value)
    }

    private func string(for account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func save(_ value: String, for account: String) {
        let base: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(base as CFDictionary)
        var item = base
        item[kSecValueData as String] = Data(value.utf8)
        item[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        SecItemAdd(item as CFDictionary, nil)
    }

    private func delete(_ account: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
    }
}
