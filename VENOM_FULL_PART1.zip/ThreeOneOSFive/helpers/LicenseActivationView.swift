import SwiftUI

struct LicenseActivationView: View {
    @ObservedObject var manager: LicenseManager
    @State private var key: String

    init(manager: LicenseManager) {
        self.manager = manager
        _key = State(initialValue: manager.rememberedKey() ?? "")
    }
    @FocusState private var keyFocused: Bool
    @State private var haloRotation = 0.0

    private var sky: Color { AppTheme.accent }
    private let muted = Color.white.opacity(0.55)

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            Circle()
                .fill(sky.opacity(0.16))
                .frame(width: 330, height: 330)
                .blur(radius: 100)
                .offset(y: -360)

            ScrollView(showsIndicators: false) {
                VStack(spacing: 0) {
                    Spacer(minLength: 24)

                    ZStack {
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .stroke(sky.opacity(0.95), lineWidth: 2)
                            .blur(radius: 9)
                            .shadow(color: sky.opacity(0.9), radius: 18)
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .trim(from: 0.03, to: 0.72)
                            .stroke(AngularGradient(colors: [sky.opacity(0.05), .white, sky, sky.opacity(0.05)], center: .center), style: StrokeStyle(lineWidth: 3, lineCap: .round))
                            .rotationEffect(.degrees(haloRotation))
                        Image("VenomLicenseArtwork")
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: 300, maxHeight: 170)
                            .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                    }
                    .frame(maxWidth: 300, maxHeight: 170)
                    .onAppear {
                        withAnimation(.linear(duration: 3.2).repeatForever(autoreverses: false)) {
                            haloRotation = 360
                        }
                    }
                    .padding(.bottom, 14)

                    Text("VENOM")
                        .font(.system(size: 31, weight: .black, design: .rounded))
                        .tracking(7)
                        .padding(.leading, 7)
                        .foregroundStyle(.white)

                    Text("LICENSE ACCESS")
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .tracking(5)
                        .foregroundStyle(.white.opacity(0.74))
                        .padding(.top, 13)

                    Text("VENOM • OFFICIAL ACCESS")
                        .font(.system(size: 10, weight: .bold, design: .rounded))
                        .tracking(2.2)
                        .foregroundStyle(muted)
                        .padding(.top, 12)

                    VStack(alignment: .leading, spacing: 14) {
                        HStack(spacing: 12) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .fill(Color.white)
                                Image(systemName: "lock.fill")
                                    .font(.system(size: 19, weight: .bold))
                                    .foregroundStyle(.black)
                            }
                            .frame(width: 60, height: 60)

                            VStack(alignment: .leading, spacing: 4) {
                                Text("LICENSE REQUIRED")
                                    .font(.system(size: 17, weight: .black, design: .rounded))
                                    .tracking(1.2)
                                    .foregroundStyle(.white)
                                Text("VENOM • LICENSE")
                                    .font(.system(size: 10, weight: .bold, design: .rounded))
                                    .tracking(1.8)
                                    .foregroundStyle(muted)
                            }
                            Spacer()
                            Image(systemName: "checkmark.seal.fill")
                                .font(.system(size: 28, weight: .bold))
                                .foregroundStyle(.white.opacity(0.78))
                        }

                        Text("Enter your VENOM license key to unlock the panel.")
                            .font(.system(size: 16, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.66))
                            .fixedSize(horizontal: false, vertical: true)

                        Text("LICENSE KEY")
                            .font(.system(size: 11, weight: .black, design: .rounded))
                            .tracking(3.5)
                            .foregroundStyle(muted)

                        HStack(spacing: 12) {
                            Image(systemName: "key.fill")
                                .foregroundStyle(sky.opacity(0.72))
                            TextField("Enter license key", text: $key)
                                .focused($keyFocused)
                                .textInputAutocapitalization(.characters)
                                .autocorrectionDisabled()
                                .submitLabel(.done)
                                .onSubmit { activate() }
                                .font(.system(size: 17, weight: .bold, design: .monospaced))
                                .foregroundStyle(.white)
                        }
                        .padding(.horizontal, 16)
                        .frame(height: 58)
                        .background(Color.black.opacity(0.46), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 17, style: .continuous).stroke(sky.opacity(0.28), lineWidth: 1))

                        Text("Buy from your seller")
                            .font(.system(size: 14, weight: .semibold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.68))
                            .frame(maxWidth: .infinity)

                        Button(action: activate) {
                            HStack(spacing: 10) {
                                if manager.isBusy { ProgressView().tint(.white) }
                                Image(systemName: manager.isBusy ? "arrow.triangle.2.circlepath" : "arrow.right.circle.fill")
                                Text(manager.isBusy ? "VERIFYING…" : (manager.rememberedKey() == nil ? "VERIFY AND CONTINUE" : "VERIFY KEY"))
                                    .font(.system(size: 13, weight: .black, design: .rounded))
                                    .tracking(2)
                            }
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 56)
                            .background(sky, in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                        }
                        .buttonStyle(.plain)
                        .disabled(manager.isBusy || key.filter { $0.isLetter || $0.isNumber }.count != 18)
                        .opacity(key.filter { $0.isLetter || $0.isNumber }.count == 18 ? 1 : 0.48)

                        if let message = manager.message {
                            Text(message)
                                .font(.system(size: 13, weight: .semibold, design: .rounded))
                                .foregroundStyle(message.localizedCaseInsensitiveContains("success") ||
                                                 message.localizedCaseInsensitiveContains("active") ||
                                                 message.localizedCaseInsensitiveContains("verified") ? .green : .orange)
                                .fixedSize(horizontal: false, vertical: true)
                                .frame(maxWidth: .infinity)
                                .multilineTextAlignment(.center)
                        }
                    }
                    .padding(20)
                    .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 28, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).stroke(sky.opacity(0.25), lineWidth: 1))
                    .padding(.horizontal, 18)
                    .padding(.top, 30)

                    Text("VENOM • SECURE LICENSE CHECK")
                        .font(.system(size: 9, weight: .bold, design: .rounded))
                        .tracking(2.1)
                        .foregroundStyle(muted.opacity(0.72))
                        .padding(.vertical, 22)
                }
                .frame(maxWidth: .infinity)
            }
            .scrollDismissesKeyboard(.interactively)
        }
        .preferredColorScheme(.dark)
    }

    private func activate() {
        keyFocused = false
        manager.activate(key: key)
    }
}
