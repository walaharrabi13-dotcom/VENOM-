import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var appState: AppState
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @AppStorage(AppAppearance.accentKey) private var accentHex = AppAppearance.defaultAccent
    @AppStorage(AppAppearance.backgroundKey) private var backgroundHex = AppAppearance.defaultBackground
    @AppStorage(AppAppearance.backgroundModeKey) private var backgroundMode = "video"
    @AppStorage("venom.soundsEnabled") private var soundsEnabled = true
    @State private var accentColor = Color(hex: AppAppearance.defaultAccent)
    @State private var backgroundColor = Color(hex: AppAppearance.defaultBackground)

    private let card = AppTheme.referenceCard

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 22) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("VENOM")
                            .font(.system(size: 23, weight: .black, design: .rounded))
                            .tracking(1.5)
                            .foregroundStyle(.white)
                        Text(language.text("common.version", appVersion))
                            .font(.system(size: 12, weight: .semibold, design: .rounded))
                            .foregroundStyle(AppTheme.secondaryAccent)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(18)
                    .background(card, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 20).stroke(AppTheme.accent.opacity(0.42), lineWidth: 1))

                    settingsSection(language.text("settings.language")) {
                        HStack(spacing: 8) {
                            languageButton("English", code: AppLanguage.english.rawValue)
                            languageButton("Español", code: AppLanguage.spanish.rawValue)
                            languageButton("العربية", code: AppLanguage.arabic.rawValue)
                        }
                    }

                    settingsSection("SOUNDS") {
                        Toggle(isOn: $soundsEnabled) {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("BUTTON SOUNDS")
                                    .font(.system(size: 12, weight: .black, design: .rounded))
                                    .foregroundStyle(.white)
                                Text("Tap, enable and disable sounds")
                                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.48))
                            }
                        }
                        .tint(AppTheme.accent)
                    }

                    settingsSection("APPEARANCE") {
                        colorPickerRow(title: "IPA COLOR", color: $accentColor)
                        Divider().overlay(AppTheme.accent.opacity(0.18))
                        HStack(spacing: 8) {
                            backgroundButton("VIDEO", value: "video", icon: "play.rectangle.fill")
                            backgroundButton("ANIMATED", value: "animated", icon: "wand.and.stars")
                            backgroundButton("SOLID", value: "solid", icon: "circle.fill")
                        }
                        if backgroundMode == "solid" {
                            Divider().overlay(AppTheme.accent.opacity(0.18))
                            colorPickerRow(title: "BACKGROUND COLOR", color: $backgroundColor)
                        }
                    }

                    settingsSection(language.text("common.device")) {
                        infoRow(language.text("dashboard.hardware_model"), value: AppInfo.displayMachineName)
                        Divider().overlay(AppTheme.accent.opacity(0.20))
                        infoRow(language.text("settings.ios_version"), value: "\(AppInfo.osVersion) (\(AppInfo.osBuild))")
                    }

                    settingsSection(language.text("settings.verified_versions")) {
                        HStack {
                            Text(language.text("settings.current_version"))
                            Spacer()
                            Text(language.text(appState.isSupported ? "settings.supported" : "settings.unsupported"))
                                .foregroundStyle(appState.isSupported ? .green : .red)
                        }
                        .font(.system(size: 15, weight: .bold, design: .rounded))
                        .padding(.vertical, 5)
                        Divider().overlay(AppTheme.accent.opacity(0.20))
                        infoRow("iOS 17", value: ExploitSupportPolicy.verifiedIOS17Range)
                        Divider().overlay(AppTheme.accent.opacity(0.20))
                        infoRow("iOS 18", value: ExploitSupportPolicy.verifiedIOS18Range)
                        Divider().overlay(AppTheme.accent.opacity(0.20))
                        infoRow("iOS 26", value: ExploitSupportPolicy.verifiedIOS26Range)
                        Divider().overlay(AppTheme.accent.opacity(0.20))
                        VStack(alignment: .leading, spacing: 8) {
                            Text("iOS 27.0").font(.system(size: 15, weight: .semibold, design: .rounded)).foregroundStyle(.white)
                            ForEach(ExploitSupportPolicy.verifiedIOS27Builds, id: \.build) { version in
                                Text(versionLabel(version))
                                    .font(.system(size: 11, weight: .medium, design: .monospaced))
                                    .foregroundStyle(.white.opacity(0.58))
                            }
                        }
                        .padding(.vertical, 5)
                    }

                    Text(language.text("settings.supported_versions_footer"))
                        .font(.system(size: 11, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.48))
                        .padding(.horizontal, 3)
                }
                .padding(18)
            }
            .background(AppTheme.pageBackground.ignoresSafeArea())
            .simultaneousGesture(TapGesture().onEnded { VenomAudio.click() })
            .onAppear {
                accentColor = Color(hex: accentHex)
                backgroundColor = Color(hex: backgroundHex)
            }
            .onChange(of: accentColor) { newColor in
                accentHex = newColor.toHex()
            }
            .onChange(of: backgroundColor) { newColor in
                backgroundHex = newColor.toHex()
            }
            .navigationTitle(language.text("settings.title"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(language.text("common.done")) { dismiss() }
                        .fontWeight(.bold)
                        .tint(AppTheme.accent)
                }
            }
            .toolbarBackground(AppTheme.pageBackground, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
        }
        .tint(AppTheme.accent)
        .preferredColorScheme(.dark)
    }

    private func settingsSection<Content: View>(_ title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title.uppercased())
                .font(.system(size: 12, weight: .black, design: .rounded))
                .tracking(1.1)
                .foregroundStyle(AppTheme.secondaryAccent)
                .padding(.leading, 4)
            VStack(spacing: 12, content: content)
                .padding(16)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(card, in: RoundedRectangle(cornerRadius: 19, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 19).stroke(AppTheme.accent.opacity(0.27), lineWidth: 1))
        }
    }

    private func languageButton(_ title: String, code: String) -> some View {
        let selected = languageCode == code
        return Button { languageCode = code } label: {
            Text(title)
                .font(.system(size: 12, weight: .bold, design: .rounded))
                .lineLimit(1)
                .minimumScaleFactor(0.75)
                .foregroundStyle(selected ? .white : .white.opacity(0.70))
                .frame(maxWidth: .infinity, minHeight: 42)
                .background(selected ? AppTheme.accent.opacity(0.42) : Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(selected ? AppTheme.secondaryAccent.opacity(0.85) : Color.white.opacity(0.08), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private func backgroundButton(_ title: String, value: String, icon: String) -> some View {
        let selected = backgroundMode == value
        return Button {
            backgroundMode = value
        } label: {
            VStack(spacing: 5) {
                Image(systemName: icon).font(.system(size: 14, weight: .bold))
                Text(title).font(.system(size: 9, weight: .black, design: .rounded))
            }
            .foregroundStyle(selected ? .white : .white.opacity(0.62))
            .frame(maxWidth: .infinity, minHeight: 52)
            .background(selected ? AppTheme.accent.opacity(0.34) : Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(selected ? AppTheme.accent : Color.white.opacity(0.09), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private func colorPickerRow(title: String, color: Binding<Color>) -> some View {
        HStack {
            Text(title)
                .font(.system(size: 12, weight: .black, design: .rounded))
                .tracking(1.1)
                .foregroundStyle(.white.opacity(0.76))
            Spacer()
            ColorPicker("", selection: color, supportsOpacity: false)
                .labelsHidden()
        }
    }

    private func infoRow(_ title: String, value: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            Text(title).foregroundStyle(.white)
            Spacer(minLength: 8)
            Text(value).foregroundStyle(.white.opacity(0.58)).multilineTextAlignment(.trailing)
        }
        .font(.system(size: 14, weight: .semibold, design: .rounded))
        .padding(.vertical, 4)
    }

    private var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "AppReleaseDisplayVersion") as? String
            ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String
            ?? "1.0"
    }

    private func versionLabel(_ version: (beta: Int, publicBeta: Int?, build: String)) -> String {
        if let publicBeta = version.publicBeta {
            return language.text("settings.developer_public_beta_build", Int64(version.beta), Int64(publicBeta), version.build)
        }
        return language.text("settings.developer_beta_build", Int64(version.beta), version.build)
    }
}
