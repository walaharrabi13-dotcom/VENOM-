import SwiftUI
import UIKit
import AVFoundation

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var licenseManager: LicenseManager
    @State private var showSettings = false
    @State private var showCleaner = false
    @State private var showUpdate = false
    @State private var neckAntinaEnabled = false
    @StateObject private var patchStore = PatchProjectStore()
    @State private var patchOperationBusy = false
    @State private var patchMessage = "READY — SELECT A PATCH"
    @State private var bodyVenomEnabled = false
    @State private var magicVenomEnabled = false
    @State private var neckVenomEnabled = false
    @State private var dragVenomEnabled = false
    @State private var gunWhiteEnabled = false
    @State private var gunBlueEnabled = false
    @State private var gunGreenEnabled = false
    @State private var gunRedEnabled = false
    @State private var alokEnabled = false
    @State private var alokV2Enabled = false
    @State private var ignisEnabled = false
    @AppStorage("venom.selectedTab") private var selectedTab = "AIM"
    @AppStorage(AppAppearance.accentKey) private var appearanceAccent = AppAppearance.defaultAccent
    @AppStorage(AppAppearance.backgroundKey) private var appearanceBackground = AppAppearance.defaultBackground
    @AppStorage(AppAppearance.backgroundModeKey) private var backgroundMode = "video"

    private var isMaintenance: Bool { licenseManager.isMaintenance }

    var body: some View {
        ZStack {
            VideoOrAnimatedBackdrop()
                .ignoresSafeArea()

            VStack(spacing: 0) {
                if isMaintenance {
                    maintenanceBanner
                }

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 18) {
                        if selectedTab == "ACCOUNT" {
                            modeHeader(title: "VENOM EXTERNAL", subtitle: "LICENSE & ACCOUNT", mode: "ACCOUNT", symbol: "person.crop.circle")
                            accountPanel
                        } else if selectedTab == "AIM" {
                            modeHeader(title: "VENOM EXTERNAL", subtitle: "AIM • FFTH PANEL", mode: "AIM", symbol: "scope")
                            aimPatchOptions
                            statusMessage
                        } else if selectedTab == "GUN WEAPON" {
                            modeHeader(title: "VENOM EXTERNAL", subtitle: "GUN WEAPON PANEL", mode: "GUN WEAPON", symbol: "scope")
                            hologramMaintenancePanel
                        } else if selectedTab == "MOD SKINS" {
                            modeHeader(title: "VENOM EXTERNAL", subtitle: "SKIN CONTROL CENTER", mode: "MOD SKINS", symbol: "sparkles")
                            patchGroup(title: "MOD SKINS", rows: [
                                ("ALOK", "Resource_05.3105", $alokEnabled),
                                ("ALOK V2", "Resource_11.3105", $alokV2Enabled),
                                ("IGNIS", "Resource_06.3105", $ignisEnabled)
                            ])
                        }
                    }
                    .padding(.horizontal, 18)
                    .padding(.top, 18)
                    .padding(.bottom, 24)
                    // Browse allowed; all action controls are disabled during maintenance.
                    .allowsHitTesting(!isMaintenance)
                    .opacity(isMaintenance ? 0.72 : 1)
                }
            }
        }
        .simultaneousGesture(TapGesture().onEnded {
            guard !isMaintenance else { return }
            VenomAudio.click()
        })
        .safeAreaInset(edge: .bottom, spacing: 0) { bottomNavigation }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showSettings) { SettingsView() }
        .sheet(isPresented: $showCleaner) { CleanerView() }
        .sheet(isPresented: $showUpdate) { UpdateInfoView() }
        .sheet(item: $patchStore.passwordRequest, onDismiss: patchStore.cancelUnlock) { _ in
            PatchUnlockPrompt(store: patchStore)
        }
        .onAppear {
            syncPatchStates()
            Task { await licenseManager.refreshMaintenanceStatus() }
        }
        .onChange(of: scenePhase) { phase in
            guard phase == .active, !patchOperationBusy else { return }
            syncPatchStates()
            patchMessage = "READY — SELECT A PATCH"
            Task { await licenseManager.refreshMaintenanceStatus() }
        }
    }

    private var maintenanceBanner: some View {
        HStack(spacing: 10) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.system(size: 14, weight: .bold))
            VStack(alignment: .leading, spacing: 2) {
                Text("MAINTENANCE MODE")
                    .font(.system(size: 11, weight: .black, design: .rounded))
                    .tracking(1.2)
                Text(licenseManager.maintenanceMessage)
                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                    .lineLimit(2)
            }
            Spacer(minLength: 0)
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .frame(maxWidth: .infinity)
        .background(Color.orange.opacity(0.92))
        .overlay(alignment: .bottom) {
            Rectangle().fill(Color.orange).frame(height: 1)
        }
    }

    private func modeHeader(title: String, subtitle: String, mode: String, symbol: String) -> some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                Text(mode)
                    .font(.system(size: 18, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                Spacer()
                Button {
                    showUpdate = true
                } label: {
                    Image(systemName: "arrow.down.circle.fill")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundStyle(AppTheme.accent)
                        .frame(width: 44, height: 44)
                        .background(Color.black.opacity(0.38), in: Circle())
                        .overlay(Circle().stroke(AppTheme.accent.opacity(0.55), lineWidth: 1))
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Open updates")
                Button {
                    showSettings = true
                } label: {
                    Image(systemName: "gearshape.fill")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundStyle(AppTheme.accent)
                        .frame(width: 44, height: 44)
                        .background(Color.black.opacity(0.38), in: Circle())
                        .overlay(Circle().stroke(AppTheme.accent.opacity(0.55), lineWidth: 1))
                }
                .buttonStyle(.plain)
            }
            HStack(spacing: 16) {
                VStack(alignment: .leading, spacing: 7) {
                    Text(title)
                        .font(.system(size: 27, weight: .black, design: .rounded))
                        .tracking(2.2)
                        .foregroundStyle(.white)
                        .minimumScaleFactor(0.75)
                        .lineLimit(2)
                    Text(subtitle)
                        .font(.system(size: 10, weight: .black, design: .rounded))
                        .tracking(2.2)
                        .foregroundStyle(AppTheme.secondaryAccent)
                }
                Spacer(minLength: 4)
                VenomGlowArtwork(imageName: "VenomArtwork", width: 104, height: 76)
            }
            .padding(18)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(AppTheme.referenceCard, in: RoundedRectangle(cornerRadius: 26, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 26, style: .continuous).stroke(AppTheme.accent.opacity(0.48), lineWidth: 1))
        }
    }

    private var bottomNavigation: some View {
        let items: [(String, String)] = [
            ("AIM", "scope"),
            ("GUN WEAPON", "scope"),
            ("MOD SKINS", "sparkles"),
            ("ACCOUNT", "person.crop.circle.fill")
        ]

        return HStack(spacing: 0) {
            ForEach(items, id: \.0) { item in
                navItem(item.0, icon: item.1)
            }
        }
        .padding(.top, 8)
        .padding(.bottom, 6)
        .background(.ultraThinMaterial)
        .overlay(alignment: .top) { Rectangle().fill(AppTheme.accent.opacity(0.30)).frame(height: 1) }
    }

    private func navItem(_ title: String, icon: String) -> some View {
        Button {
            withAnimation(.easeInOut(duration: 0.18)) { selectedTab = title }
        } label: {
            VStack(spacing: 5) {
                Group {
                    Image(systemName: icon)
                        .font(.system(size: 19, weight: .semibold))
                }
                Text(title).font(.system(size: 7.5, weight: .bold, design: .rounded)).lineLimit(1).minimumScaleFactor(0.55)
            }
            .foregroundStyle(selectedTab == title ? AppTheme.accent : .white.opacity(0.58))
            .frame(maxWidth: .infinity)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private func placeholderPanel(title: String, subtitle: String, symbol: String) -> some View {
        VStack(spacing: 12) {
            Image(systemName: symbol).font(.system(size: 32, weight: .semibold)).foregroundStyle(AppTheme.accent)
            Text(title).font(.system(size: 19, weight: .black, design: .rounded)).foregroundStyle(.white)
            Text(subtitle).font(.system(size: 12, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.55)).multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, minHeight: 190)
        .padding(20)
        .background(Color.black.opacity(0.55), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(AppTheme.accent.opacity(0.35), lineWidth: 1))
    }

    private var statusMessage: some View {
        HStack(spacing: 8) {
            Circle().fill(patchMessage.localizedCaseInsensitiveContains("successful") ? .green : AppTheme.accent).frame(width: 7, height: 7)
            Text(patchOperationBusy ? "PROCESSING…" : patchMessage)
                .font(.system(size: 10, weight: .bold, design: .rounded)).foregroundStyle(.white.opacity(0.72)).lineLimit(2)
            Spacer()
        }
        .padding(.horizontal, 12).padding(.vertical, 10)
        .background(Color.black.opacity(0.34), in: Capsule())
    }

    private var brandHeader: some View {
        HStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 3) {
                Text("VENOM EXTERNAL")
                    .font(.system(size: 20, weight: .black, design: .rounded))
                    .tracking(0.8)
                    .lineLimit(1)
                    .minimumScaleFactor(0.75)
                    .foregroundStyle(.white)
                Text("PATCH CONTROL CENTER")
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .tracking(1.7)
                    .foregroundStyle(AppTheme.accent)
            }

            Spacer()

            Button {
                showSettings = true
            } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(AppTheme.accent)
                    .frame(width: 48, height: 48)
                    .background(Color.black.opacity(0.38), in: Circle())
                    .overlay(Circle().stroke(AppTheme.accent.opacity(0.42), lineWidth: 1))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Open settings")
        }
    }

    private var devicePanel: some View {
        VStack(spacing: 0) {
            panelTitle("DEVICE STATUS", icon: "shield.lefthalf.filled")
            statusRow(icon: "apple.logo", title: "iOS", value: AppInfo.osVersion, color: AppTheme.secondaryAccent)
            statusRow(icon: "iphone", title: "Device", value: AppInfo.displayMachineName, color: AppTheme.secondaryAccent)
            statusRow(icon: "checkmark.seal.fill", title: "Support", value: appState.isSupported ? "SUPPORTED" : "UNSUPPORTED", color: appState.isSupported ? .green : .red)
        }
        .padding(16)
        .background(Color.black.opacity(0.42), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(AppTheme.accent.opacity(0.38), lineWidth: 1))
    }

    private var accountPanel: some View {
        AccountLicensePanel(manager: licenseManager)
    }

    private var aimPatchOptions: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                panelTitle("AIM / FFTH", icon: "scope")
                Spacer()
                Text("SELECT TO ENABLE")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
            }

            patchGroup(title: "AIM PATCHES", rows: [
                ("BODY VENOM", "Resource_07.3105", $bodyVenomEnabled),
                ("DRAG VENOM", "Resource_08.3105", $dragVenomEnabled),
                ("NECK ANTINA", "Resource_09.3105", $neckAntinaEnabled),
                ("NECK VENOM", "Resource_10.3105", $neckVenomEnabled)
            ])
        }
    }

    private var gunWeaponOptions: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                panelTitle("GUN WEAPON", icon: "scope")
                Spacer()
                Text("SELECT TO ENABLE")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
            }

            patchGroup(title: "GUN WEAPON • HOLO", rows: [
                ("Holo White", "Resource_01.3105", $gunWhiteEnabled),
                ("Holo Bleu", "Resource_02.3105", $gunBlueEnabled),
                ("Holo Green", "Resource_03.3105", $gunGreenEnabled),
                ("Holo Red", "Resource_04.3105", $gunRedEnabled)
            ])
        }
    }

    private var hologramMaintenancePanel: some View {
        VStack(spacing: 18) {
            Image(systemName: "wrench.and.screwdriver.fill")
                .font(.system(size: 42, weight: .bold))
                .foregroundStyle(AppTheme.accent)
            Text("UNDER MAINTENANCE")
                .font(.system(size: 22, weight: .black, design: .rounded))
                .tracking(1.6)
                .foregroundStyle(.white)
            Text("HOLOGRAM")
                .font(.system(size: 28, weight: .black, design: .rounded))
                .tracking(3)
                .foregroundStyle(AppTheme.accent)
            Text("This section is temporarily unavailable.\nPlease check back later.")
                .font(.system(size: 13, weight: .medium, design: .rounded))
                .foregroundStyle(.white.opacity(0.62))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, minHeight: 240)
        .padding(24)
        .background(Color.black.opacity(0.55), in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .stroke(AppTheme.accent.opacity(0.45), lineWidth: 1)
        )
    }

    private func maintenanceGroup(title: String, names: [String]) -> some View {
        VStack(alignment: .leading, spacing: 9) {
            Text(title)
                .font(.system(size: 11, weight: .black, design: .rounded))
                .tracking(1.8)
                .foregroundStyle(AppTheme.secondaryAccent)
                .padding(.leading, 3)
            VStack(spacing: 0) {
                ForEach(Array(names.enumerated()), id: \.offset) { index, name in
                    HStack(spacing: 14) {
                        Image(systemName: "bolt.fill")
                            .font(.system(size: 19, weight: .black))
                            .foregroundStyle(AppTheme.secondaryAccent.opacity(0.55))
                            .frame(width: 28)
                        Text(name)
                            .font(.system(size: 16, weight: .bold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.72))
                        Spacer()
                        Text("IN MAINTENANCE")
                            .font(.system(size: 9, weight: .black, design: .rounded))
                            .tracking(0.5)
                            .foregroundStyle(.orange)
                    }
                    .padding(.horizontal, 15)
                    .padding(.vertical, 15)
                    if index != names.count - 1 {
                        Rectangle().fill(AppTheme.accent.opacity(0.20)).frame(height: 1).padding(.leading, 56)
                    }
                }
            }
            .background(Color.black.opacity(0.48), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(AppTheme.accent.opacity(0.34), lineWidth: 1))
        }
    }

    private func lockedPatchRow(name: String, status: String) -> some View {
        HStack(spacing: 14) {
            Image(systemName: "lock.fill")
                .font(.system(size: 17, weight: .black))
                .foregroundStyle(AppTheme.secondaryAccent.opacity(0.55))
                .frame(width: 28)
            Text(name)
                .font(.system(size: 16, weight: .bold, design: .rounded))
                .foregroundStyle(.white.opacity(0.72))
            Spacer()
            Text(status)
                .font(.system(size: 10, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.55))
        }
        .padding(.horizontal, 15)
        .padding(.vertical, 15)
        .background(Color.black.opacity(0.48), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(AppTheme.accent.opacity(0.24), lineWidth: 1))
    }

    private func patchGroup(title: String, rows: [(String, String, Binding<Bool>)]) -> some View {
        VStack(alignment: .leading, spacing: 9) {
            Text(title)
                .font(.system(size: 11, weight: .black, design: .rounded))
                .tracking(1.8)
                .foregroundStyle(AppTheme.secondaryAccent)
                .padding(.leading, 3)
            VStack(spacing: 0) {
                ForEach(Array(rows.enumerated()), id: \.offset) { index, row in
                    patchRow(name: row.0, package: row.1, state: row.2, isLast: index == rows.count - 1)
                }
            }
            .background(Color.black.opacity(0.48), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(AppTheme.accent.opacity(0.34), lineWidth: 1))
        }
    }

    private func patchRow(name: String, package: String, state: Binding<Bool>, isLast: Bool = false) -> some View {
        VStack(spacing: 0) {
            Button {
                togglePatch(packageFilename: package, enabled: !state.wrappedValue, state: state)
            } label: {
                HStack(spacing: 14) {
                    Image(systemName: "bolt.fill")
                        .font(.system(size: 19, weight: .black))
                        .foregroundStyle(AppTheme.secondaryAccent)
                        .frame(width: 28)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(name)
                            .font(.system(size: 16, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                        Text("FREE FIRE • FFTH")
                            .font(.system(size: 9, weight: .black, design: .rounded))
                            .tracking(1.2)
                            .foregroundStyle(AppTheme.secondaryAccent)
                    }
                    Spacer(minLength: 4)
                    Text(state.wrappedValue ? "ON" : "OFF")
                        .font(.system(size: 11, weight: .black, design: .rounded))
                        .foregroundStyle(state.wrappedValue ? AppTheme.secondaryAccent : .white.opacity(0.48))
                    ZStack(alignment: state.wrappedValue ? .trailing : .leading) {
                        Capsule()
                            .fill(state.wrappedValue ? AppTheme.accent : Color.white.opacity(0.18))
                            .frame(width: 48, height: 28)
                        Circle()
                            .fill(.white)
                            .frame(width: 22, height: 22)
                            .padding(3)
                            .shadow(color: .black.opacity(0.22), radius: 2, y: 1)
                    }
                    .frame(width: 48, height: 28)
                    .animation(.easeOut(duration: 0.10), value: state.wrappedValue)
                }
                .padding(.horizontal, 15)
                .padding(.vertical, 15)
                .contentShape(Rectangle())
            }
            .buttonStyle(PatchQuickPressStyle())
            .disabled(patchOperationBusy)
            .accessibilityLabel("\(name), \(state.wrappedValue ? "on" : "off")")
            .accessibilityHint("Tap anywhere on this row to change its state")
            if !isLast {
                Rectangle()
                    .fill(AppTheme.accent.opacity(0.20))
                    .frame(height: 1)
                    .padding(.leading, 56)
            }
        }
    }

    private func launchButton(title: String, subtitle: String, color: Color, scheme: String) -> some View {
        Button { openGame(scheme: scheme) } label: {
            VStack(alignment: .leading, spacing: 7) {
                Image(systemName: "arrow.up.right.square.fill")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(color)
                Text(title)
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text(subtitle)
                    .font(.system(size: 10, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.5))
            }
            .frame(maxWidth: .infinity, minHeight: 82, alignment: .leading)
            .padding(.horizontal, 14)
            .background(Color.black.opacity(0.40), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(color.opacity(0.38), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private var developerCredits: some View {
        VStack(spacing: 10) {
            Text("Developed By Venom Team")
                .font(.system(size: 11, weight: .bold, design: .rounded))
                .foregroundStyle(.white.opacity(0.72))
                .multilineTextAlignment(.center)

            Text("Our Telegram channels")
                .font(.system(size: 10, weight: .semibold, design: .rounded))
                .foregroundStyle(AppTheme.secondaryAccent.opacity(0.85))

            VStack(spacing: 10) {
                channelButton(title: "Dark Telegram", url: "https://t.me/store_wwe")
                channelButton(title: "BlaskoXiter Telegram", url: "https://t.me/blaskoxiter")
                channelButton(title: "JineX Telegram", url: "https://t.me/jnxsq1")
            }
        }
        .frame(maxWidth: .infinity)
        .padding(.top, 4)
        .padding(.bottom, 8)
    }

    private func channelButton(title: String, url: String) -> some View {
        Button {
            guard let destination = URL(string: url) else { return }
            UIApplication.shared.open(destination)
        } label: {
            Label(title, systemImage: "paperplane.fill")
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .padding(.horizontal, 12)
                .padding(.vertical, 9)
                .background(AppTheme.accent.opacity(0.18), in: Capsule())
                .overlay(Capsule().stroke(AppTheme.accent.opacity(0.42), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private func panelTitle(_ title: String, icon: String) -> some View {
        Label(title, systemImage: icon)
            .font(.system(size: 12, weight: .black, design: .rounded))
            .tracking(1.4)
            .foregroundStyle(AppTheme.accent)
    }

    private func statusRow(icon: String, title: String, value: String, color: Color) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon).font(.system(size: 17, weight: .bold)).foregroundStyle(color).frame(width: 24)
            Text(title).font(.system(size: 14, weight: .semibold, design: .rounded)).foregroundStyle(.white.opacity(0.58))
            Spacer()
            Text(value).font(.system(size: 14, weight: .black, design: .rounded)).foregroundStyle(.white)
        }
        .padding(.top, 14)
    }

    private func syncPatchStates() {
        withAnimation(.easeOut(duration: 0.10)) {
            neckVenomEnabled = isPatchActive("Resource_10.3105")
            neckAntinaEnabled = isPatchActive("Resource_09.3105")
            dragVenomEnabled = isPatchActive("Resource_08.3105")
            bodyVenomEnabled = isPatchActive("Resource_07.3105")
            gunWhiteEnabled = isPatchActive("Resource_01.3105")
            gunBlueEnabled = isPatchActive("Resource_02.3105")
            gunGreenEnabled = isPatchActive("Resource_03.3105")
            gunRedEnabled = isPatchActive("Resource_04.3105")
            alokEnabled = isPatchActive("Resource_05.3105")
            alokV2Enabled = isPatchActive("Resource_11.3105")
            ignisEnabled = isPatchActive("Resource_06.3105")
        }
    }

    private func isPatchActive(_ packageFilename: String) -> Bool {
        patchStore.items.first(where: { $0.packageURL.lastPathComponent.caseInsensitiveCompare(packageFilename) == .orderedSame })
            .flatMap { DevicePatchService.latestReceipt(projectID: $0.id) } != nil
    }

    private enum PatchActionResult {
        case applied
        case restored
        case unavailable(String)
    }

    private func setPatchState(for packageFilename: String, enabled: Bool) {
        withAnimation(.easeOut(duration: 0.10)) {
            switch packageFilename {
            case "Resource_07.3105": bodyVenomEnabled = enabled
            case "Resource_09.3105": neckAntinaEnabled = enabled
            case "Resource_10.3105": neckVenomEnabled = enabled
            case "Resource_08.3105": dragVenomEnabled = enabled
            case "Resource_01.3105": gunWhiteEnabled = enabled
            case "Resource_02.3105": gunBlueEnabled = enabled
            case "Resource_03.3105": gunGreenEnabled = enabled
            case "Resource_04.3105": gunRedEnabled = enabled
            case "Resource_05.3105": alokEnabled = enabled
            case "Resource_11.3105": alokV2Enabled = enabled
            case "Resource_06.3105": ignisEnabled = enabled
            default: break
            }
        }
    }

    private func togglePatch(packageFilename: String, enabled: Bool, state: Binding<Bool>) {
        guard !patchOperationBusy else { return }
        guard enabled != state.wrappedValue else { return }

        guard let item = patchStore.items.first(where: {
            $0.packageURL.lastPathComponent.caseInsensitiveCompare(packageFilename) == .orderedSame
        }) else {
            patchMessage = "ERROR — PACKAGE NOT FOUND"
            log("patch: package not found: \(packageFilename)")
            return
        }

        let project = item.project
        let projectID = item.id
        patchOperationBusy = true
        patchMessage = enabled ? "ENABLING — \(packageFilename)" : "DISABLING — \(packageFilename)"

        DispatchQueue.global(qos: .userInitiated).async {
            let result: PatchActionResult
            do {
                if enabled {
                    guard let project else {
                        DispatchQueue.main.async {
                            self.patchStore.requestUnlock(for: item)
                            self.patchMessage = "PASSWORD REQUIRED — ENTER PACKAGE PASSWORD"
                            self.patchOperationBusy = false
                        }
                        return
                    }
                    _ = try DevicePatchService.apply(project: project)
                    result = .applied
                } else {
                    guard let receipt = DevicePatchService.latestReceipt(projectID: projectID) else {
                        DispatchQueue.main.async {
                            self.patchMessage = "RESTORE UNAVAILABLE — ACTIVE BACKUP RECEIPT NOT FOUND"
                            self.patchOperationBusy = false
                        }
                        return
                    }
                    try DevicePatchService.restore(receipt: receipt)
                    result = .restored
                }
            } catch {
                result = .unavailable("FAILED — \(String(describing: error))")
            }

            DispatchQueue.main.async {
                switch result {
                case .applied:
                    self.setPatchState(for: packageFilename, enabled: true)
                    self.patchMessage = "ENABLED — \(packageFilename)"
                    VenomAudio.activated()
                case .restored:
                    self.setPatchState(for: packageFilename, enabled: false)
                    self.patchMessage = "DISABLED — \(packageFilename)"
                    VenomAudio.deactivated()
                case .unavailable(let message):
                    self.patchMessage = message
                    self.syncPatchStates()
                }
                self.patchOperationBusy = false
            }
        }
    }

    private func openGame(scheme: String) {
        guard let url = URL(string: "\(scheme)://") else { return }
        UIApplication.shared.open(url, options: [:]) { success in
            log("launch: \(scheme) success=\(success)")
        }
    }
}


private struct PatchQuickPressStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.985 : 1.0)
            .opacity(configuration.isPressed ? 0.88 : 1.0)
            .animation(.easeOut(duration: 0.09), value: configuration.isPressed)
    }
}


private struct PatchUnlockPrompt: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: PatchProjectStore
    @State private var password = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField("Package password", text: $password)
                        .textContentType(.password)
                        .submitLabel(.done)
                        .onSubmit(unlock)
                        .onChange(of: password) { _ in store.clearUnlockError() }
                    if let errorKey = store.unlockErrorKey {
                        Text(AppLanguage.english.text(errorKey))
                            .font(.footnote)
                            .foregroundStyle(.red)
                    }
                } footer: {
                    Text("Enter the password once to unlock this VENOM package on this device.")
                }
            }
            .navigationTitle("Unlock package")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Unlock", action: unlock)
                        .disabled(password.isEmpty || store.isBusy)
                }
            }
        }
    }

    private func unlock() {
        guard !password.isEmpty else { return }
        store.unlock(password: password)
    }
}

struct VideoOrAnimatedBackdrop: View {
    var body: some View {
        ZStack {
            switch AppAppearance.backgroundMode {
            case "solid":
                AppTheme.pageBackground
            case "animated":
                AnimatedHyperBackdrop()
            default:
                if let url = Bundle.main.url(forResource: "VENOM_BACKGROUND", withExtension: "mp4") {
                    LoopingVideoBackground(url: url)
                    Color.black.opacity(0.34)
                } else {
                    AnimatedHyperBackdrop()
                }
            }
        }
    }
}

struct LoopingVideoBackground: UIViewRepresentable {
    let url: URL

    func makeUIView(context: Context) -> PlayerView {
        let view = PlayerView()
        view.play(url: url)
        return view
    }

    func updateUIView(_ uiView: PlayerView, context: Context) {}
}

final class PlayerView: UIView {
    private var player: AVQueuePlayer?
    private var looper: AVPlayerLooper?
    private var playerLayer: AVPlayerLayer?

    override class var layerClass: AnyClass { AVPlayerLayer.self }

    func play(url: URL) {
        let item = AVPlayerItem(url: url)
        let queue = AVQueuePlayer(items: [item])
        looper = AVPlayerLooper(player: queue, templateItem: item)
        player = queue
        if let layer = layer as? AVPlayerLayer {
            layer.player = queue
            layer.videoGravity = .resizeAspectFill
        }
        queue.isMuted = true
        queue.volume = 0
        queue.play()
    }
}

struct AnimatedHyperBackdrop: View {
    @State private var animate = false
    var body: some View {
        GeometryReader { proxy in
            ZStack {
                AppTheme.pageBackground
                Circle()
                    .fill(AppTheme.accent.opacity(0.12))
                    .frame(width: 280, height: 280)
                    .blur(radius: 70)
                    .offset(x: animate ? 120 : -120, y: -proxy.size.height * 0.23)
                Circle()
                    .fill(AppTheme.secondaryAccent.opacity(0.08))
                    .frame(width: 260, height: 260)
                    .blur(radius: 80)
                    .offset(x: animate ? -100 : 100, y: proxy.size.height * 0.22)
                GridOverlay()
            }
            .onAppear {
                withAnimation(.easeInOut(duration: 7).repeatForever(autoreverses: true)) { animate = true }
            }
        }
    }
}

private struct GridOverlay: View {
    var body: some View {
        Canvas { context, size in
            var path = Path()
            let spacing: CGFloat = 44
            stride(from: CGFloat(0), through: size.width, by: spacing).forEach { x in
                path.move(to: CGPoint(x: x, y: 0)); path.addLine(to: CGPoint(x: x, y: size.height))
            }
            stride(from: CGFloat(0), through: size.height, by: spacing).forEach { y in
                path.move(to: CGPoint(x: 0, y: y)); path.addLine(to: CGPoint(x: size.width, y: y))
            }
            context.stroke(path, with: .color(AppTheme.accent.opacity(0.055)), lineWidth: 1)
        }
    }
}


private struct AccountLicensePanel: View {
    @ObservedObject var manager: LicenseManager
    @State private var showLogoutConfirmation = false
    @State private var showAppearance = false
    @State private var revealLicenseKey = false
    @AppStorage(AppAppearance.accentKey) private var accentHex = AppAppearance.defaultAccent
    @State private var accentColor = Color(hex: AppAppearance.defaultAccent)

    private var maskedKey: String {
        guard let key = manager.rememberedKey(), !key.isEmpty else { return "SESSION ONLY" }
        let prefix = String(key.prefix(4))
        let suffix = String(key.suffix(4))
        return "\(prefix) •••••• \(suffix)"
    }

    private var visibleKey: String {
        manager.rememberedKey().flatMap { $0.isEmpty ? nil : $0 } ?? "SESSION ONLY"
    }

    private var deviceQuotaText: String {
        switch (manager.deviceCount, manager.deviceLimit) {
        case let (count?, limit?):
            return "\(count) / \(limit) USED"
        case let (count?, nil):
            return "\(count) USED"
        case let (nil, limit?):
            return "LIMIT \(limit)"
        default:
            return "NOT PROVIDED"
        }
    }

    var body: some View {
        VStack(spacing: 16) {
            VStack(spacing: 12) {
                HStack {
                    Label("KEY EXPIRATION", systemImage: "clock.fill")
                        .font(.system(size: 11, weight: .black, design: .rounded))
                        .tracking(1.5)
                        .foregroundStyle(AppTheme.secondaryAccent)
                    Spacer()
                    Text(manager.isActive ? "ACTIVE" : "INACTIVE")
                        .font(.system(size: 10, weight: .black, design: .rounded))
                        .tracking(1.2)
                        .foregroundStyle(manager.isActive ? .green : .red)
                }

                TimelineView(.periodic(from: .now, by: 1)) { timeline in
                    let remaining = max(0, (manager.expirationDate ?? timeline.date).timeIntervalSince(timeline.date))
                    VStack(spacing: 6) {
                        Text(manager.expirationDate == nil ? "NO EXPIRY DATA" : expirationCountdown(remaining))
                            .font(.system(size: 34, weight: .black, design: .rounded).monospacedDigit())
                            .tracking(1.2)
                            .foregroundStyle(remaining > 0 ? AppTheme.secondaryAccent : .red)
                            .minimumScaleFactor(0.62)
                            .lineLimit(1)
                        Text(manager.expirationDate == nil ? "Expiration is not supplied by the server" : countdownCaption(remaining))
                            .font(.system(size: 9, weight: .bold, design: .rounded))
                            .tracking(1.4)
                            .foregroundStyle(.white.opacity(0.48))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                }
            }
            .padding(18)
            .background(Color.black.opacity(0.48), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(AppTheme.accent.opacity(0.52), lineWidth: 1))

            VStack(spacing: 0) {
                HStack(spacing: 12) {
                    Image(systemName: "person.fill")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundStyle(AppTheme.secondaryAccent)
                        .frame(width: 22)
                    VStack(alignment: .leading, spacing: 4) {
                        Text("ACCOUNT").font(.system(size: 9, weight: .black, design: .rounded)).tracking(1.2).foregroundStyle(.white.opacity(0.48))
                        Text(revealLicenseKey ? visibleKey : maskedKey)
                            .font(.system(size: 12, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                            .minimumScaleFactor(0.65)
                    }
                    Spacer(minLength: 4)
                    Button {
                        revealLicenseKey.toggle()
                        VenomAudio.click()
                    } label: {
                        Image(systemName: revealLicenseKey ? "eye.slash.fill" : "eye.fill")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundStyle(AppTheme.secondaryAccent)
                            .frame(width: 36, height: 36)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel(revealLicenseKey ? "Hide license key" : "Show license key")
                }
                .padding(.vertical, 14)
                Rectangle().fill(AppTheme.accent.opacity(0.18)).frame(height: 1)
                accountRow(icon: "checkmark.shield.fill", title: "LICENSE STATUS", value: manager.isActive ? "VALID ON THIS DEVICE" : "NOT ACTIVE")
                Rectangle().fill(AppTheme.accent.opacity(0.18)).frame(height: 1)
                accountRow(icon: "calendar", title: "EXPIRES AT", value: manager.expirationDate.map { $0.formatted(date: .abbreviated, time: .shortened) } ?? "NOT PROVIDED")
                Rectangle().fill(AppTheme.accent.opacity(0.18)).frame(height: 1)
                accountRow(
                    icon: "iphone.gen3",
                    title: "DEVICES",
                    value: deviceQuotaText
                )
            }
            .padding(.horizontal, 15)
            .background(Color.black.opacity(0.42), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(AppTheme.accent.opacity(0.32), lineWidth: 1))

            if !manager.notifications.isEmpty {
                VStack(alignment: .leading, spacing: 10) {
                    Text("NOTIFICATIONS")
                        .font(.system(size: 11, weight: .black, design: .rounded))
                        .tracking(1.4)
                        .foregroundStyle(AppTheme.secondaryAccent)
                    ForEach(manager.notifications.prefix(5)) { note in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(note.title)
                                .font(.system(size: 13, weight: .bold, design: .rounded))
                                .foregroundStyle(.white)
                            if !note.body.isEmpty {
                                Text(note.body)
                                    .font(.system(size: 12, weight: .medium, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.7))
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                        }
                        .padding(12)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    }
                }
                .padding(14)
                .background(Color.black.opacity(0.42), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(AppTheme.accent.opacity(0.32), lineWidth: 1))
            }

            Button { showAppearance = true } label: {
                Label("CHANGE IPA COLOR", systemImage: "paintpalette.fill")
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .tracking(1.6)
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 52)
                    .background(AppTheme.accent.opacity(0.22), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(AppTheme.accent.opacity(0.52), lineWidth: 1))
            }
            .buttonStyle(.plain)

            Button { showLogoutConfirmation = true } label: {
                Label("LOGOUT", systemImage: "rectangle.portrait.and.arrow.right")
                    .font(.system(size: 12, weight: .black, design: .rounded))
                    .tracking(2)
                    .foregroundStyle(AppTheme.secondaryAccent)
                    .frame(maxWidth: .infinity)
                    .frame(height: 52)
                    .background(Color.black.opacity(0.32), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(AppTheme.accent.opacity(0.55), lineWidth: 1))
            }
            .buttonStyle(.plain)
        }
        .sheet(isPresented: $showAppearance) {
            NavigationStack {
                Form {
                    Section("IPA COLOR") {
                        ColorPicker("Choose interface color", selection: $accentColor, supportsOpacity: false)
                    }
                }
                .navigationTitle("VENOM APPEARANCE")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .confirmationAction) {
                        Button("DONE") { showAppearance = false }
                    }
                }
                .preferredColorScheme(.dark)
            }
            .onAppear { accentColor = Color(hex: accentHex) }
            .onChange(of: accentColor) { newColor in accentHex = newColor.toHex() }
        }
        .confirmationDialog("Log out of VENOM?", isPresented: $showLogoutConfirmation, titleVisibility: .visible) {
            Button("LOGOUT", role: .destructive) { manager.deactivate() }
            Button("CANCEL", role: .cancel) { }
        } message: {
            Text("This removes the saved license from this device.")
        }
    }

    private func expirationCountdown(_ remaining: TimeInterval) -> String {
        let total = max(0, Int(remaining))
        let days = total / 86_400
        let hours = (total % 86_400) / 3_600
        let minutes = (total % 3_600) / 60
        let seconds = total % 60
        if days > 0 {
            return String(format: "%dD %02d:%02d:%02d", days, hours, minutes, seconds)
        }
        let totalHours = total / 3_600
        return String(format: "%02d:%02d:%02d", totalHours, minutes, seconds)
    }

    private func countdownCaption(_ remaining: TimeInterval) -> String {
        if remaining >= 86_400 { return "DAYS  :  HOURS  :  MINUTES  :  SECONDS" }
        return "HOURS  :  MINUTES  :  SECONDS"
    }

    private func accountRow(icon: String, title: String, value: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(AppTheme.secondaryAccent)
                .frame(width: 22)
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.system(size: 9, weight: .black, design: .rounded)).tracking(1.2).foregroundStyle(.white.opacity(0.48))
                Text(value).font(.system(size: 12, weight: .bold, design: .rounded)).foregroundStyle(.white).lineLimit(1).minimumScaleFactor(0.7)
            }
            Spacer(minLength: 4)
        }
        .padding(.vertical, 14)
    }
}


private struct VenomGlowArtwork: View {
    let imageName: String
    let width: CGFloat
    let height: CGFloat
    @State private var rotation = 0.0

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 15, style: .continuous)
                .stroke(AppTheme.accent.opacity(0.9), lineWidth: 2)
                .blur(radius: 7)
                .shadow(color: AppTheme.accent.opacity(0.9), radius: 13)
            RoundedRectangle(cornerRadius: 15, style: .continuous)
                .trim(from: 0.04, to: 0.72)
                .stroke(
                    AngularGradient(colors: [AppTheme.accent.opacity(0.05), .white, AppTheme.accent, AppTheme.accent.opacity(0.05)], center: .center),
                    style: StrokeStyle(lineWidth: 2.5, lineCap: .round)
                )
                .rotationEffect(.degrees(rotation))
            Image(imageName)
                .resizable()
                .scaledToFill()
                .frame(width: width - 5, height: height - 5)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
        .frame(width: width, height: height)
        .onAppear {
            withAnimation(.linear(duration: 3.2).repeatForever(autoreverses: false)) {
                rotation = 360
            }
        }
        .accessibilityHidden(true)
    }
}

private struct UpdateInfoView: View {
    @State private var apiOnline = false
    @State private var checkingAPI = true
    @State private var releaseNotes: [ReleaseNoteItem] = []
    @State private var notesLoading = true
    @State private var notesError: String?

    private let appVersion = "1.0.2"

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 18) {
                    VStack(spacing: 10) {
                        Text("VENOM UPDATE")
                            .font(.system(size: 23, weight: .black, design: .rounded))
                            .tracking(2)
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                        Text("VERSION \(appVersion)")
                            .font(.system(size: 14, weight: .bold, design: .rounded))
                            .foregroundStyle(AppTheme.accent)
                            .frame(maxWidth: .infinity)
                        HStack(spacing: 9) {
                            Circle().fill(apiOnline ? .green : .red).frame(width: 9, height: 9)
                            Text(checkingAPI ? "API STATUS : CHECKING" : (apiOnline ? "API STATUS : ONLINE" : "API STATUS : OFFLINE"))
                                .font(.system(size: 12, weight: .bold, design: .rounded))
                                .foregroundStyle(apiOnline ? .green : (checkingAPI ? .white : .red))
                        }
                        .frame(maxWidth: .infinity)
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        Text("RELEASE NOTES")
                            .font(.system(size: 11, weight: .black, design: .rounded))
                            .tracking(1.6)
                            .foregroundStyle(AppTheme.secondaryAccent)

                        if notesLoading {
                            HStack(spacing: 10) {
                                ProgressView().tint(AppTheme.accent)
                                Text("Loading release notes…")
                                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.7))
                            }
                            .padding(.vertical, 8)
                        } else if let notesError {
                            Text(notesError)
                                .font(.system(size: 12, weight: .medium, design: .rounded))
                                .foregroundStyle(.white.opacity(0.55))
                                .fixedSize(horizontal: false, vertical: true)
                        } else if releaseNotes.isEmpty {
                            Text("No release notes published for \(appVersion) yet.")
                                .font(.system(size: 12, weight: .medium, design: .rounded))
                                .foregroundStyle(.white.opacity(0.55))
                        } else {
                            ForEach(releaseNotes) { note in
                                VStack(alignment: .leading, spacing: 6) {
                                    HStack {
                                        Text(note.title)
                                            .font(.system(size: 13, weight: .bold, design: .rounded))
                                            .foregroundStyle(.white)
                                        Spacer()
                                        if let version = note.version {
                                            Text("v\(version)")
                                                .font(.system(size: 10, weight: .bold, design: .rounded))
                                                .foregroundStyle(AppTheme.accent)
                                        }
                                    }
                                    if !note.body.isEmpty {
                                        Text(note.body)
                                            .font(.system(size: 12, weight: .medium, design: .rounded))
                                            .foregroundStyle(.white.opacity(0.72))
                                            .fixedSize(horizontal: false, vertical: true)
                                    }
                                }
                                .padding(14)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                                        .stroke(AppTheme.accent.opacity(0.28), lineWidth: 1)
                                )
                            }
                        }
                    }
                    .padding(16)
                    .background(Color.black.opacity(0.42), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .stroke(AppTheme.accent.opacity(0.35), lineWidth: 1)
                    )

                    Link(destination: URL(string: "https://t.me/UpdatesVenom")!) {
                        HStack {
                            Image(systemName: "paperplane.fill")
                            Text("OPEN UPDATE CHANNEL")
                        }
                        .font(.system(size: 12, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(AppTheme.accent.opacity(0.24), in: Capsule())
                        .overlay(Capsule().stroke(AppTheme.accent.opacity(0.65), lineWidth: 1))
                    }

                    Spacer(minLength: 12)
                }
                .padding(28)
                .padding(.top, 12)
            }
        }
        .task {
            async let status: Void = checkAPIStatus()
            async let notes: Void = loadReleaseNotes()
            _ = await (status, notes)
        }
        .preferredColorScheme(.dark)
    }

    private func checkAPIStatus() async {
        guard let url = URL(string: "https://venom-api-v-2--i76241724.replit.app/api/client/status") else {
            checkingAPI = false
            apiOnline = false
            return
        }
        do {
            var request = URLRequest(url: url)
            request.httpMethod = "GET"
            request.timeoutInterval = 8
            let (_, response) = try await URLSession.shared.data(for: request)
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            apiOnline = (200...299).contains(status)
        } catch {
            apiOnline = false
        }
        checkingAPI = false
    }

    private func loadReleaseNotes() async {
        notesLoading = true
        notesError = nil
        defer { notesLoading = false }

        // Prefer client-facing public path if the server exposes one later;
        // fall back to the admin path (may require auth).
        let candidates = [
            "https://venom-api-v-2--i76241724.replit.app/api/client/release-notes",
            "https://venom-api-v-2--i76241724.replit.app/api/release-notes"
        ]

        for urlString in candidates {
            guard let url = URL(string: urlString) else { continue }
            do {
                var request = URLRequest(url: url)
                request.httpMethod = "GET"
                request.timeoutInterval = 10
                let (data, response) = try await URLSession.shared.data(for: request)
                guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
                    continue
                }
                let items = Self.parseReleaseNotes(data: data, preferredVersion: appVersion)
                if !items.isEmpty {
                    releaseNotes = items
                    return
                }
                // Empty but successful response — stop trying other endpoints.
                releaseNotes = []
                return
            } catch {
                continue
            }
        }

        notesError = "Release notes are managed from the VENOM API dashboard. Publish notes for \(appVersion) to show them here."
    }

    private static func parseReleaseNotes(data: Data, preferredVersion: String) -> [ReleaseNoteItem] {
        // Accept either a raw array or an object with `items` / `notes` / `data`.
        let json = (try? JSONSerialization.jsonObject(with: data))
        let rawItems: [[String: Any]]
        if let arr = json as? [[String: Any]] {
            rawItems = arr
        } else if let obj = json as? [String: Any] {
            rawItems = (obj["items"] as? [[String: Any]])
                ?? (obj["notes"] as? [[String: Any]])
                ?? (obj["data"] as? [[String: Any]])
                ?? []
        } else {
            return []
        }

        let mapped: [ReleaseNoteItem] = rawItems.compactMap { dict in
            let title = (dict["title"] as? String)
                ?? (dict["headline"] as? String)
                ?? (dict["name"] as? String)
                ?? "Release note"
            let body = (dict["body"] as? String)
                ?? (dict["content"] as? String)
                ?? (dict["description"] as? String)
                ?? (dict["message"] as? String)
                ?? ""
            let version = (dict["version"] as? String)
                ?? (dict["appVersion"] as? String)
                ?? (dict["tag"] as? String)
            return ReleaseNoteItem(
                id: (dict["id"] as? String) ?? UUID().uuidString,
                title: title,
                body: body,
                version: version
            )
        }

        let forVersion = mapped.filter { ($0.version ?? "") == preferredVersion }
        return forVersion.isEmpty ? mapped : forVersion
    }
}

private struct ReleaseNoteItem: Identifiable {
    let id: String
    let title: String
    let body: String
    let version: String?
}
